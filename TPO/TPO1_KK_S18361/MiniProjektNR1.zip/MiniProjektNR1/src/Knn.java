import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;

public class Knn {
    private List<String> Training = new ArrayList<>();
    private List<String> Test = new ArrayList<>();
    double testSize;
    double accuracy;
    public Knn() {}

    public void comparingTest(int k) {
        String wynik = null;
        for (String s : Test) {
//            List<String> neighbor = new ArrayList<>();
            //List<tmp> neighbor = new ArrayList<>();
            List<MySet> neighborV2= new ArrayList<>();
            String[] line = s.split(",");
            double similarity = 0;
            MySet mySet=new MySet(line);

            com(neighborV2,mySet);

            //System.out.println(similarity);
            for(int i = 0;i < k;i++){
                if(neighborV2.get(i).getName().equals(mySet.getName())) {
                    similarity+=((double) 100/k);
                }
            }
            if(similarity>=50){
                //accuracy++;
                accuracy+=similarity;
            }
            //accuracy+=similarity;

            //neighbor.clear();
            neighborV2.clear();
        }
        //System.out.println("correctly classified from the test file based on the training file: " + (int) accuracy);
        System.out.println("the accuracy for " + k + " is: " + (accuracy  / testSize) + "%");

    }

    public void newTest() {
        Scanner scan = new Scanner(System.in);

        String s= Training.get(0);
        String[] line = s.split(",");
        String[] zmienne=new String[line.length-1];

        for(int i=0;i<line.length-1;i++){
            System.out.println("podaj wartość ");
            zmienne[i] = scan.nextLine();

        }
        System.out.println("podaj parametr k");
        int k = scan.nextInt();
        //String[] line = zmienne.split(",");
        MySet mySetNewTest=new MySet(zmienne,"NowyTest");
        int irisS = 0;
        int irisVe = 0;
        int irisVi = 0;
        List<MySet> neighborV2 = new ArrayList<>();

        com(neighborV2,mySetNewTest);

        System.out.println("neighbors: ");
        for(int i=0;i<k;i++) {
            System.out.println(neighborV2.get(i).getName());
        }
        for (int i = 0; i < k; i++) {
            if(neighborV2.get(i).getName().equals("Iris-setosa")) {
                irisS++;
            } else if (neighborV2.get(i).getName().equals("Iris-versicolor")) {
                irisVe++;
            } else if (neighborV2.get(i).getName().equals("Iris-virginica")) {
                irisVi++;
            }
        }
        if (irisS > irisVe && irisS > irisVi) {
            System.out.println("assignment to : iris-setosa");
        } else if (irisVe > irisS && irisVe > irisVi) {
            System.out.println("assignment to : iris-versicolor");
        } else if(irisVi > irisVe && irisVi > irisS){
            System.out.println("assignment to : iris-virginica");
        }
    }
    //Reading data files
    public void readFile(String path,String mode) throws IOException {
        FileReader fileReader = new FileReader(path);
        BufferedReader bufferedReader = new BufferedReader(fileReader);
        String textLine = bufferedReader.readLine();
        if(mode.equals("training")) {
            do {
                Training.add(textLine);
                textLine = bufferedReader.readLine();
            } while (textLine != null);
            bufferedReader.close();
        }else if(mode.equals("test")){
            do {
                //System.out.println(textLine);
                Test.add(textLine);
                textLine = bufferedReader.readLine();
                //amount of data in the test file
                testSize++;
            } while (textLine != null);
            bufferedReader.close();
        }
    }

    public void com(List<MySet> nighborV2,MySet mySet){
    for(String a:Training){
            String[] line=a.split(",");
            double distance=0;

            double[] results=new double[line.length-1];
            for(int i=0;i<results.length;i++){
                results[i]=Math.pow(mySet.getValue(i) - Double.parseDouble(line[i]),2);
                distance+=results[i];
            }
            MySet tmpSet= new MySet(Math.sqrt(distance),line[line.length-1]);

            nighborV2.add(tmpSet);
            Collections.sort(nighborV2, new Comparator<MySet>() {
                @Override
                public int compare(MySet o1, MySet o2) {
                    return Double.compare(o1.getDistance(),o2.getDistance());
                }
            });

        }
    }

}