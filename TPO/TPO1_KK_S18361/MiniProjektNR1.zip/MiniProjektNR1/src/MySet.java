public class MySet{
    double[] value;
    String name;
    double distance;

    MySet(String[] line)
    {
        int tmp=line.length;
        tmp--;
        this.value=new double[tmp];
        for(int i=0;i<tmp;i++){
            this.value[i]=Double.parseDouble(line[i]);
        }
        this.name=line[line.length-1];
        //this.distance=distance;
    }
    MySet(String[] line,String mode)
    {
        if(mode.equals("NowyTest")){
        int tmp=line.length;
        this.value=new double[tmp];
        for(int i=0;i<tmp;i++){
            this.value[i]=Double.parseDouble(line[i]);
        }
        this.name=line[line.length-1];
        //this.distance=distance;
    }}
    MySet (double distance, String name){
        this.name=name;
        this.distance=distance;
    }

    public double getValue(int i){
        return this.value[i];
    }
    public void setDistance(double d){
        this.distance=d;
    }
    public double getDistance(){
        return distance;
    }

    public String toString(){
        return this.name;
    }
    public String getName(){
        return this.name;
    }

}
