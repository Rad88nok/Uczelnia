/**
 *
 *  @author Kazimierczyk Konrad S18361
 *
 */

package zad1;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.XML;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;


import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Currency;
import java.util.Locale;

public class Service {
    String city, currencyCountry = "", currency = "";

    String country;
    Double rate;

    Service(String country) {
        this.country = country;
    }

    private String getContentFromUrl(URL content) throws IOException {
        StringBuilder sb = new StringBuilder();
        String wrt;
        BufferedReader in = new BufferedReader(new InputStreamReader(content.openStream()));

        while ((wrt = in.readLine()) != null) sb.append(wrt);
        in.close();

        return sb.toString();
    }

    public String getWeather(String city)  {
        this.city = city;
        String weatherResponse = null;

        try {
            weatherResponse = getContentFromUrl(new URL("http://api.openweathermap.org/data/2.5/weather?q=" + this.city + "," + this.country + "&APPID=ef684ca343ba36cb7f605a7c518f7f70"));
        } catch (IOException e) {
            e.printStackTrace();
        }

        return weatherResponse;
    }

    private String findCurrencyCountry() {
        Locale[] locale = Locale.getAvailableLocales();

        for (Locale l : locale)
            if (l.getDisplayCountry(Locale.ENGLISH).equals(country))
                return Currency.getInstance(l).getCurrencyCode();

        return "PLN";
    }

    Double getNBPRate() {//zwraca kurs złotego wobec waluty danego kraju

        String xmlNBP_A = getContentFromUrl("http://www.nbp.pl/kursy/xml/a057z170322.xml");
        String xmlNBP_B = getContentFromUrl("http://www.nbp.pl/kursy/xml/b012z170322.xml");

        if (!xmlNBP_A.isEmpty() && !xmlNBP_B.isEmpty()) {
            JSONObject jsonObjectA = XML.toJSONObject(xmlNBP_A);
            JSONObject jsonObjectB = XML.toJSONObject(xmlNBP_B);
            JSONArray jsonArray = new JSONArray();
            jsonArray.put(jsonObjectA);
            jsonArray.put(jsonObjectB);
            double rateToPLN = 0.0;

//          JSONObject obj = jsonObjectA.optJSONObject(weather.getCountryCurrencyCode());
            JSONObject objCurrency = findCurrencyRateNBP(jsonArray);
            if (objCurrency != null) {//found currency
                rateToPLN = objCurrency.optDouble("kurs_sredni");
                nbpRateObj = objCurrency;
            }
            return rateToPLN;
        }
        return null;
    }

    public Double getRateFor(String currency) {
        String currencyResponse;
        currencyCountry = findCurrencyCountry();
        System.out.println("getRateFor: " + currencyCountry + " to: " + currency);
        JSONObject currencyJson, nestedJson;

        try {
            currencyResponse = getContentFromUrl(new URL("https://api.exchangerate.host/latest?base=" + currencyCountry));

            currencyJson = new JSONObject(currencyResponse);
            nestedJson = currencyJson.getJSONObject("rates");
            this.rate = nestedJson.getDouble(currency);


        }catch (JSONException e){
            System.out.println(e);
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return this.rate;
    }
}